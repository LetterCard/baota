#coding: utf-8
import os,sys,time,re,json
os.chdir('/www/server/panel/')
sys.path.insert(0,"class/")
import public

#设置用户状态
def SetStatus(get):
    msg = public.getMsg('OFF')
    if get.status != '0': msg = public.getMsg('ON')
    try:
        id = get['id']
        username = get['username']
        status = get['status']
        runPath = '/www/server/pure-ftpd/bin'
        if int(status)==0:
            public.ExecShell(runPath + '/pure-pw usermod ' + username + ' -r 1')
        else:
            public.ExecShell(runPath + '/pure-pw usermod ' + username + " -r ''")
        FtpReload()
        public.M('ftps').where("id=?",(id,)).setField('status',status)
        public.WriteLog('TYPE_FTP','FTP_STATUS', (msg,username))
        return public.returnMsg(True, 'SUCCESS')
    except Exception as ex:
        public.WriteLog('TYPE_FTP','FTP_STATUS_ERR', (msg,username,str(ex)))
        return public.returnMsg(False,'FTP_STATUS_ERR',(msg,))

def FtpReload():
    runPath = '/www/server/pure-ftpd/bin'
    public.ExecShell(runPath + '/pure-pw mkdb /www/server/pure-ftpd/etc/pureftpd.pdb')


#面板日志分析统计
def logs_analysis():
    logs_path = '/www/server/panel/logs/request/'
    logs_tips = logs_path + 'tips/'
    admin_path = public.readFile('/www/server/panel/data/admin_path.pl')
    exolode_mods = ['data','warning','message','workorder','login','public','code','wxapp','webhook','webssh']
    if admin_path: 
        admin_path = admin_path.replace('/','')
        if admin_path: exolode_mods.append(admin_path)
    explode_names = ['GetNetWork','get_task_lists','get_index_list','UpdatePanel',
    'GetTaskCount','get_config','get_site_types','get_load_average','GetCpuIo',
    'GetDiskIo','GetNetWorkIo','SetControl','GetDirSize','GetSshInfo','get_host_list',
    'get_command_list','GetDataList','get_soft_list','upload','check_two_step','get_settings',
    'get_menu_list','GetSpeed','getConfigHtml','get_sync_task_find','get_buy_code','get_install_log']

    if not os.path.exists(logs_path): return
    if not os.path.exists(logs_tips): os.makedirs(logs_tips,384)
    import re
    if sys.version_info[0] == 2:
        from urlparse import parse_qs, urlparse
    else:
        from urllib.parse import parse_qs, urlparse
        
    for fname in os.listdir(logs_path):
        if fname in ['tips']:continue
        day_date = fname.split('.')[0]
        filename = logs_path + fname.replace('.gz','')
        tip_file = logs_tips + day_date + '.pl'
        if os.path.exists(tip_file): continue
        if fname[-2:] != 'gz': continue
        public.ExecShell("cd {} && gunzip {}".format(logs_path,fname))
        if not os.path.exists(filename): continue
        public.ExecShell("cd {} && gzip {}".format(logs_path,fname.replace('.gz','')))
        public.writeFile(tip_file,'')



oldEdate = public.readFile('data/edate.pl')
if not oldEdate: oldEdate = '0000-00-00'
mEdate = time.strftime('%Y-%m-%d',time.localtime())
edateSites = public.M('sites').where('edate>? AND edate<=? AND (status=? OR status=?)',('0000-00-00',mEdate,1,u'正在运行')).field('id,name').select()
import panelSite
siteObject = panelSite.panelSite()
for site in edateSites:
    get = public.dict_obj()
    get.id = site['id']
    get.name = site['name']
    siteObject.SiteStop(get)
    
    bind_ftp = public.M('ftps').where('pid=?',get.id).find()
    if bind_ftp:
        get = public.dict_obj()
        get.id = bind_ftp['id']
        get.username = bind_ftp['name']
        get.status = '0'
        SetStatus(get)
oldEdate = mEdate
public.writeFile('/www/server/panel/data/edate.pl',mEdate)
logs_analysis()
